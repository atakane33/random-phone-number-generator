﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rastgele_Telefon_Numarası_Üretme_Programı
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            int[] dizi = new int[11];

            Random rakam = new Random();

            string satir = Environment.NewLine;

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 5; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;
                
                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }

            a.Show();

            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 10; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;
                    
                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 15; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 7; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 31; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 69; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 100; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 1000; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {

                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();

            a.Show();

            this.Hide();

            int[] dizi = new int[11];

            string satir = Environment.NewLine;

            Random rakam = new Random();

            int rastgele = rakam.Next(0, 10);

            for (int b = 0; b < 10000; b++)
            {
                a.textBox1.Text = a.textBox1.Text + satir;

                for (int i = 0; i < dizi.Length; i++)
                {
                    dizi[i] = rakam.Next(0, 10);

                    dizi[0] = 0;

                    dizi[1] = 5;

                    string dönüstür = Convert.ToString(dizi[i]);

                    a.textBox1.Text = a.textBox1.Text + dönüstür;

                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
